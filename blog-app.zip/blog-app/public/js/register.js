const form = document.getElementById('form');
const errorEl = document.getElementById('error');

if (store.token) location.href = '/';

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  errorEl.textContent = '';
  const button = form.querySelector('button');
  button.disabled = true;

  try {
    const data = await api('/auth/register', {
      method: 'POST',
      body: {
        name: document.getElementById('name').value.trim(),
        email: document.getElementById('email').value.trim(),
        password: document.getElementById('password').value,
      },
    });
    store.save(data.token, data.user);
    location.href = safeNext();
  } catch (err) {
    errorEl.textContent = err.message;
    button.disabled = false;
  }
});
