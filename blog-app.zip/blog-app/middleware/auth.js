const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Protects routes: requires "Authorization: Bearer <token>"
async function protect(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ message: 'Please log in to continue' });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);
    if (!user) return res.status(401).json({ message: 'This account no longer exists' });

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Your session is invalid or has expired. Please log in again' });
  }
}

module.exports = { protect };
