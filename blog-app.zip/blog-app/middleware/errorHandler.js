// Central error handler: turns thrown errors into clean JSON responses
function errorHandler(err, req, res, next) {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ message: 'Request body is not valid JSON' });
  }
  if (err.name === 'ValidationError') {
    const message = Object.values(err.errors).map((e) => e.message).join('. ');
    return res.status(400).json({ message });
  }
  if (err.name === 'CastError') {
    return res.status(400).json({ message: 'Invalid ID' });
  }
  if (err.code === 11000) {
    return res.status(409).json({ message: 'An account with this email already exists' });
  }
  console.error(err);
  res.status(500).json({ message: 'Server error. Please try again' });
}

module.exports = errorHandler;
