// Shared helpers: API calls, login state, navigation.
// The frontend is served by the same Express server, so the API lives at /api.
// If you host the frontend elsewhere, change API_BASE to e.g. 'http://localhost:5000/api'.
const API_BASE = '/api';

const store = {
  get token() {
    return localStorage.getItem('token');
  },
  get user() {
    try {
      return JSON.parse(localStorage.getItem('user') || 'null');
    } catch (e) {
      return null;
    }
  },
  save(token, user) {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(user));
  },
  clear() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  },
};

async function api(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (store.token) headers.Authorization = 'Bearer ' + store.token;

  let res;
  try {
    res = await fetch(API_BASE + path, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch (e) {
    throw new Error('Cannot reach the server. Check that it is running.');
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && store.token) store.clear(); // expired or invalid session
    throw new Error(data.message || 'Something went wrong. Try again.');
  }
  return data;
}

function formatDate(iso) {
  return new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

function renderNav() {
  const nav = document.getElementById('nav');
  if (!nav) return;
  nav.replaceChildren();

  const link = (text, href) => {
    const a = document.createElement('a');
    a.textContent = text;
    a.href = href;
    if (location.pathname === href) a.setAttribute('aria-current', 'page');
    nav.appendChild(a);
  };

  if (store.token && store.user) {
    link('Write', '/create-blog.html');
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'link-btn';
    btn.textContent = 'Log out (' + store.user.name + ')';
    btn.addEventListener('click', () => {
      store.clear();
      location.href = '/';
    });
    nav.appendChild(btn);
  } else {
    link('Log in', '/login.html');
    link('Create account', '/register.html');
  }
}

// Only allow redirects to our own pages, e.g. "create-blog.html"
function safeNext() {
  const next = new URLSearchParams(location.search).get('next');
  return next && /^[a-z-]+\.html$/.test(next) ? '/' + next : '/';
}

document.addEventListener('DOMContentLoaded', renderNav);
