const express = require('express');
const { createBlog, getBlogs, getBlog } = require('../controllers/blogController');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.get('/', getBlogs);
router.get('/:id', getBlog);
router.post('/', protect, createBlog);

module.exports = router;
