(async function () {
  const status = document.getElementById('status');
  const list = document.getElementById('posts');

  try {
    const { blogs } = await api('/blogs');

    if (blogs.length === 0) {
      status.textContent = 'No posts yet. Log in and write the first one.';
      return;
    }
    status.hidden = true;

    for (const blog of blogs) {
      const li = document.createElement('li');
      const a = document.createElement('a');
      a.href = '/post.html?id=' + encodeURIComponent(blog._id);

      const title = document.createElement('h3');
      title.textContent = blog.title;

      const excerpt = document.createElement('p');
      excerpt.className = 'excerpt';
      excerpt.textContent = blog.content.length > 180 ? blog.content.slice(0, 180).trim() + '…' : blog.content;

      const meta = document.createElement('p');
      meta.className = 'meta';
      meta.textContent = 'by ' + (blog.author ? blog.author.name : 'Unknown') + ' on ' + formatDate(blog.createdAt);

      a.append(title, excerpt, meta);
      li.appendChild(a);
      list.appendChild(li);
    }
  } catch (err) {
    status.textContent = err.message;
    status.classList.add('is-error');
  }
})();
