# Fieldnotes: Blog App with Node.js, Express & MongoDB

A full-stack blog application. The backend is a REST API built with **Node.js + Express.js** (user registration, login, create blog) and the frontend is plain HTML, CSS and JavaScript connected to those APIs.

> Built as part of a backend development internship task.

## Key objectives

- [x] Set up a backend server using Node.js and Express.js
- [x] Create REST APIs for the application
- [x] Build APIs for User Registration, User Login and Create Blog
- [x] Connect the frontend with the backend APIs

## Tech stack

| Layer | Tools |
|---|---|
| Server | Node.js, Express.js |
| Database | MongoDB with Mongoose |
| Auth | JSON Web Tokens (JWT), bcryptjs password hashing |
| Frontend | HTML, CSS, vanilla JavaScript (`fetch`) |

## Project structure

```
blog-app/
├── server.js                  # Express app entry point
├── config/db.js               # MongoDB connection
├── models/                    # User and Blog schemas
├── controllers/               # Request logic (auth, blogs)
├── routes/                    # API route definitions
├── middleware/                # JWT auth guard, error handler
├── public/                    # Frontend (served by Express)
│   ├── index.html             # Home: list of posts
│   ├── register.html
│   ├── login.html
│   ├── create-blog.html       # Write a post (login required)
│   ├── post.html              # Read a single post
│   ├── css/style.css
│   └── js/                    # API helper + one script per page
├── .env.example
└── package.json
```

## Getting started

**Prerequisites:** [Node.js](https://nodejs.org) 18+ and [MongoDB](https://www.mongodb.com/try/download/community) running locally (or a free [MongoDB Atlas](https://www.mongodb.com/atlas) connection string).

```bash
# 1. Install dependencies
npm install

# 2. Create your environment file
cp .env.example .env        # on Windows: copy .env.example .env
# then open .env and set MONGO_URI and a long random JWT_SECRET

# 3. Start the server
npm start                   # or: npm run dev (auto-restart on changes)
```

Open **http://localhost:5000**. The frontend and API run from the same server.

## API reference

Base URL: `http://localhost:5000/api`

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | `/auth/register` | No | Create an account |
| POST | `/auth/login` | No | Log in and receive a JWT |
| GET | `/auth/me` | Yes | Get the logged-in user |
| POST | `/blogs` | Yes | Create a blog post |
| GET | `/blogs` | No | List all posts (newest first) |
| GET | `/blogs/:id` | No | Get one post |

Protected routes need the header `Authorization: Bearer <token>`.

### Register

`POST /api/auth/register`

```json
{ "name": "Asha", "email": "asha@example.com", "password": "secret12" }
```

Response `201`:

```json
{ "token": "<jwt>", "user": { "id": "...", "name": "Asha", "email": "asha@example.com" } }
```

### Login

`POST /api/auth/login`

```json
{ "email": "asha@example.com", "password": "secret12" }
```

Response `200`: same shape as register. Wrong credentials return `401`.

### Create blog

`POST /api/blogs` (requires token)

```json
{ "title": "Why I started a blog", "content": "First post..." }
```

Response `201`:

```json
{ "blog": { "_id": "...", "title": "Why I started a blog", "content": "First post...", "author": { "name": "Asha" }, "createdAt": "..." } }
```

### Try it with curl

```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Asha","email":"asha@example.com","password":"secret12"}'

curl -X POST http://localhost:5000/api/blogs \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"title":"Hello","content":"My first post"}'
```

## How the frontend connects to the API

`public/js/common.js` holds one `api()` helper that calls `fetch('/api/...')`, attaches the saved JWT as a Bearer token, and throws readable errors. Each page script (`login.js`, `register.js`, `create.js`, `home.js`, `post.js`) uses it. The token is stored in `localStorage` after login or registration, and the navigation bar updates based on whether it exists.

If you host the frontend separately from the server, change `API_BASE` at the top of `common.js` to `http://localhost:5000/api`. CORS is already enabled.

## Security notes

- Passwords are hashed with bcrypt and never returned by the API.
- Routes that change data are protected by JWT middleware.
- The frontend renders user content with `textContent`, which prevents script injection.
- Never commit `.env`. It is listed in `.gitignore`.

## Push to GitHub

```bash
git init
git add .
git commit -m "Blog app: Express REST API and frontend"
git branch -M main
git remote add origin https://github.com/<your-username>/blog-app.git
git push -u origin main
```

## Possible improvements

- Edit and delete posts (author only)
- Pagination on the home page
- Rate limiting on login (`express-rate-limit`)
- Store the JWT in an httpOnly cookie instead of `localStorage`

## License

MIT
