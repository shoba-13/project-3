(async function () {
  const status = document.getElementById('status');
  const id = new URLSearchParams(location.search).get('id');

  if (!id) {
    status.textContent = 'No post selected.';
    return;
  }

  try {
    const { blog } = await api('/blogs/' + encodeURIComponent(id));
    document.title = blog.title + ' · Fieldnotes';
    document.getElementById('post-title').textContent = blog.title;
    document.getElementById('post-meta').textContent =
      'by ' + (blog.author ? blog.author.name : 'Unknown') + ' on ' + formatDate(blog.createdAt);
    document.getElementById('post-body').textContent = blog.content;
    status.hidden = true;
    document.getElementById('post').hidden = false;
  } catch (err) {
    status.textContent = err.message;
    status.classList.add('is-error');
  }
})();
