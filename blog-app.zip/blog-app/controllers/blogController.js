const Blog = require('../models/Blog');

// POST /api/blogs  (protected)
exports.createBlog = async (req, res, next) => {
  try {
    const { title, content } = req.body || {};

    if (!title || !title.trim() || !content || !content.trim()) {
      return res.status(400).json({ message: 'Title and content are required' });
    }

    const blog = await Blog.create({ title, content, author: req.user._id });
    await blog.populate('author', 'name');
    res.status(201).json({ blog });
  } catch (err) {
    next(err);
  }
};

// GET /api/blogs
exports.getBlogs = async (req, res, next) => {
  try {
    const blogs = await Blog.find().sort({ createdAt: -1 }).populate('author', 'name');
    res.json({ count: blogs.length, blogs });
  } catch (err) {
    next(err);
  }
};

// GET /api/blogs/:id
exports.getBlog = async (req, res, next) => {
  try {
    const blog = await Blog.findById(req.params.id).populate('author', 'name');
    if (!blog) return res.status(404).json({ message: 'Blog not found' });
    res.json({ blog });
  } catch (err) {
    next(err);
  }
};
