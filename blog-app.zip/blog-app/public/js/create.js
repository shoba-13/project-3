const form = document.getElementById('form');
const errorEl = document.getElementById('error');

// Only logged-in users can write
if (!store.token) location.href = '/login.html?next=create-blog.html';

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  errorEl.textContent = '';
  const button = form.querySelector('button');
  button.disabled = true;

  try {
    const { blog } = await api('/blogs', {
      method: 'POST',
      body: { title: document.getElementById('title').value.trim(), content: document.getElementById('content').value.trim() },
    });
    location.href = '/post.html?id=' + encodeURIComponent(blog._id);
  } catch (err) {
    errorEl.textContent = err.message;
    button.disabled = false;
    if (!store.token) location.href = '/login.html?next=create-blog.html';
  }
});
